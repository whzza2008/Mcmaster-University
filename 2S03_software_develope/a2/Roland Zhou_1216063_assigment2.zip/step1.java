package se2s03;

public class BadCode {
    
    
    public static int f5(int x, int y, int z) {
        int i,aa,bb,cc;
        i = (x * x) + 20;
        aa = (11 * x) + (56 - y);
        while (i <= 0) {
            bb = (z * y) - 11;
        }
        i = (y * y) + 20;
        bb = (41 * z) + (x - 56);
        while (i <= 0) {
            cc = (x * x) * z;
        }
        i = (z * z) + 20;
        cc = (18 * y) + (y - x);
        while (i <= 0) {
            aa = z - 41;
        }
        return (aa + bb) + cc;
    }
}

