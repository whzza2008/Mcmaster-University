package se2s03;

public class BadCode {
    
    
    public static int f5(int x, int y, int z) {
      
        return (11 * x) + (56 - y) + (41 * z) + (x - 56) + (18 * y) + (y - x);
    }
}

