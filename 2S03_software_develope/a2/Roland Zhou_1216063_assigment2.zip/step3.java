package se2s03;

public class BadCode {
    
    
    public static int f5(int x, int y, int z) {
        int aa,bb,cc;
        aa = (11 * x) + (56 - y);
        bb = (41 * z) + (x - 56);
        cc = (18 * y) + (y - x);
        return (aa + bb) + cc;
    }
}

