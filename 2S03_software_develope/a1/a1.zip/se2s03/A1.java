package se2s03;

public class A1 {
    public int cases(int v, int u, int w) {
        return 0;
    } 
}
